#!/bin/bash
python3 gateway_admin
python3 system_gateway